# Upfront Web Automation

Project dependencies
- robotframework-seleniumlibrary
- robotframework-faker

** Install project dependencies **
git `pip install -r requirements.txt --use-deprecated=legacy-resolver`

## Enable Google Sheet Reporting 
`export GS_REPORT=True`
url link: 
https://docs.google.com/spreadsheets/d/1l1JWbs8pHKjgKzShzFHLEsABNoaYyo3BHrSpIyktbsc/edit#gid=0
## Enable Telegram Reporting 
Use `export TG_REPORT=True`

Use `export TG_REPORT=Full` to display full result in the Telegram

channel_id: `@UpfrontAuto`

## Run Scipt
git `robot -d result -i upfront suites/`

